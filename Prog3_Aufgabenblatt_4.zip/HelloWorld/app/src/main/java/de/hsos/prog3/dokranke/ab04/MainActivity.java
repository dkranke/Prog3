package de.hsos.prog3.dokranke.ab04;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.time.LocalDateTime;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Canvas canvas;
    private Bitmap bitmap;
    private Paint paint;
    private int breite = 800;
    private int hoehe = 800;

    private int textsize = 50;

    private Timer timer = new Timer();

    int grenzeLinks = 30;
    int grenzeRechts = 770;
    int grenzeOben = 400;
    int grenzeUnten = 770;

    int ballRadius = 20;
    float ballX = 100f;
    float ballY = 700f;
    float velociteX = 0.3f;
    float velociteY = 4.5f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.bitmap = Bitmap.createBitmap(this.breite, this.hoehe, Bitmap.Config.ARGB_8888);
        this.canvas = new Canvas(this.bitmap);
        this.imageView = new ImageView(this);
        this.imageView.setImageBitmap(this.bitmap);
        this.paint = new Paint();

        setContentView(imageView);

        this.canvas.drawColor(Color.argb(255, 0, 0, 255));
        this.paint.setTextSize(50);
        this.halloWelt();

        this.halloNachbarn();

        this.zeichneSmiley(100);

        derSpringendePunkt();
        this.timer.schedule(new TimerTask() {
            @Override
            public void run() {
                derSpringendePunkt();
            }
        }, 0, 17);
    }

    private void halloWelt() {
        String text = "Hallo Welt!";
        float textWidth = this.paint.measureText(text);
        this.paint.setColor(Color.WHITE);
        this.canvas.drawText(text, breite / 2 - textWidth / 2, 100, this.paint);
    }

    private void halloNachbarn() {
        String text = "Hallo Nachbarn!";
        this.paint.setColor(Color.WHITE);
        textZentrieren(text, 155);
    }

    private void textZentrieren(String text, int y) {
        float x = (this.breite - this.paint.measureText(text)) / 2;
        this.canvas.drawText(text, x, y, this.paint);
    }

    public void zeichneSmiley(int radius) {
        this.paint.setColor(Color.GREEN);
        int y = 500;
        this.canvas.drawCircle(this.breite / 2, y, radius, this.paint);
        this.paint.setColor(Color.BLACK);
        this.canvas.drawCircle(this.breite / 2 - radius / 2.5f, y - radius / 2.5f, 15, this.paint);
        this.canvas.drawCircle(this.breite / 2 + radius / 2.5f, y - radius / 2.5f, 15, this.paint);
        this.canvas.drawLine(this.breite / 2 - radius / 2, y + radius / 3, this.breite / 2 + radius / 2, y + radius / 3, this.paint);
    }

    public void derSpringendePunkt() {
        this.paint.setColor(Color.BLUE);
        this.canvas.drawCircle(ballX, ballY, ballRadius, this.paint);

        this.ballX += this.velociteX;
        this.ballY += this.velociteY;
        if (this.ballX < grenzeLinks || this.ballX > grenzeRechts) {
            this.velociteX *= -1;
        }
        if (this.ballY < grenzeOben || this.ballY > grenzeUnten) {
            this.velociteY *= -1;
        }

        this.paint.setColor(Color.RED);
        this.canvas.drawCircle(ballX, ballY, ballRadius, this.paint);

        this.imageView.invalidate();
        // Log.i("MainActivity", LocalDateTime.now() + ": der springende Punkt");
    }
}
